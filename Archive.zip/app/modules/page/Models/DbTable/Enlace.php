<?php 

/**
* 
*/
class Page_Model_DbTable_Enlace extends Db_Table
{
	/**
	 * [ nombre de la tabla actual]
	 * @var string
	 */
	protected $_name = 'enlaces';

	/**
	 * [ identificador de la tabla actual en la base de datos]
	 * @var string
	 */
	protected $_id = 'enlaces_id';
}