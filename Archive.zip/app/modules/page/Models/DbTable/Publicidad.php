<?php 

/**
* 
*/
class Page_Model_DbTable_Publicidad extends Db_Table
{
	protected $_name = 'publicidad';
	protected $_id = 'publicidad_id';
}