
<h1 class="titulo-principal"><i class="fas fa-cogs"></i> <?php echo $this->titlesection; ?></h1>
<div class="container-fluid">
	<form class="text-left" enctype="multipart/form-data" method="post" action="<?php echo $this->routeform;?>"  data-bs-toggle="validator">
		<div class="content-dashboard">
			<input type="hidden" name="csrf" id="csrf" value="<?php echo $this->csrf ?>">
			<input type="hidden" name="csrf_section" id="csrf_section" value="<?php echo $this->csrf_section ?>">
			<?php if ($this->content->pedido_producto_id) { ?>
				<input type="hidden" name="id" id="id" value="<?= $this->content->pedido_producto_id; ?>" />
			<?php }?>
			<div class="row">
				<div class="col-12 form-group">
					<label class="control-label">pedido_producto_pedido</label>
					<label class="input-group">
						<div class="input-group-prepend">
							<span class="input-group-text input-icono  " ><i class="far fa-list-alt"></i></span>
						</div>
						<select class="form-control" name="pedido_producto_pedido"   >
							<option value="">Seleccione...</option>
							<?php foreach ($this->list_pedido_producto_pedido AS $key => $value ){?>
								<option <?php if($this->getObjectVariable($this->content,"pedido_producto_pedido") == $key ){ echo "selected"; }?> value="<?php echo $key; ?>" /> <?= $value; ?></option>
							<?php } ?>
						</select>
					</label>
					<div class="help-block with-errors"></div>
				</div>
				<div class="col-12 form-group">
					<label class="control-label">pedido_producto_producto</label>
					<label class="input-group">
						<div class="input-group-prepend">
							<span class="input-group-text input-icono  " ><i class="far fa-list-alt"></i></span>
						</div>
						<select class="form-control" name="pedido_producto_producto"   >
							<option value="">Seleccione...</option>
							<?php foreach ($this->list_pedido_producto_producto AS $key => $value ){?>
								<option <?php if($this->getObjectVariable($this->content,"pedido_producto_producto") == $key ){ echo "selected"; }?> value="<?php echo $key; ?>" /> <?= $value; ?></option>
							<?php } ?>
						</select>
					</label>
					<div class="help-block with-errors"></div>
				</div>
				<div class="col-12 form-group">
					<label for="pedido_producto_nombre"  class="control-label">pedido_producto_nombre</label>
					<label class="input-group">
						<div class="input-group-prepend">
							<span class="input-group-text input-icono " ><i class="fas fa-pencil-alt"></i></span>
						</div>
						<input type="text" value="<?= $this->content->pedido_producto_nombre; ?>" name="pedido_producto_nombre" id="pedido_producto_nombre" class="form-control"   >
					</label>
					<div class="help-block with-errors"></div>
				</div>
				<div class="col-12 form-group">
					<label for="pedido_producto_imagen"  class="control-label">pedido_producto_imagen</label>
					<label class="input-group">
						<div class="input-group-prepend">
							<span class="input-group-text input-icono " ><i class="fas fa-pencil-alt"></i></span>
						</div>
						<input type="text" value="<?= $this->content->pedido_producto_imagen; ?>" name="pedido_producto_imagen" id="pedido_producto_imagen" class="form-control"   >
					</label>
					<div class="help-block with-errors"></div>
				</div>
				<div class="col-12 form-group">
					<label for="pedido_producto_cantidad"  class="control-label">pedido_producto_cantidad</label>
					<label class="input-group">
						<div class="input-group-prepend">
							<span class="input-group-text input-icono " ><i class="fas fa-pencil-alt"></i></span>
						</div>
						<input type="text" value="<?= $this->content->pedido_producto_cantidad; ?>" name="pedido_producto_cantidad" id="pedido_producto_cantidad" class="form-control"   >
					</label>
					<div class="help-block with-errors"></div>
				</div>
				<div class="col-12 form-group">
					<label for="pedido_producto_valor"  class="control-label">pedido_producto_valor</label>
					<label class="input-group">
						<div class="input-group-prepend">
							<span class="input-group-text input-icono " ><i class="fas fa-pencil-alt"></i></span>
						</div>
						<input type="text" value="<?= $this->content->pedido_producto_valor; ?>" name="pedido_producto_valor" id="pedido_producto_valor" class="form-control"   >
					</label>
					<div class="help-block with-errors"></div>
				</div>
				<div class="col-12 form-group">
					<label for="pedido_producto_valor_impuestos"  class="control-label">pedido_producto_valor_impuestos</label>
					<label class="input-group">
						<div class="input-group-prepend">
							<span class="input-group-text input-icono " ><i class="fas fa-pencil-alt"></i></span>
						</div>
						<input type="text" value="<?= $this->content->pedido_producto_valor_impuestos; ?>" name="pedido_producto_valor_impuestos" id="pedido_producto_valor_impuestos" class="form-control"   >
					</label>
					<div class="help-block with-errors"></div>
				</div>
				<div class="col-12 form-group">
					<label for="pedido_producto_valor_total"  class="control-label">pedido_producto_valor_total</label>
					<label class="input-group">
						<div class="input-group-prepend">
							<span class="input-group-text input-icono " ><i class="fas fa-pencil-alt"></i></span>
						</div>
						<input type="text" value="<?= $this->content->pedido_producto_valor_total; ?>" name="pedido_producto_valor_total" id="pedido_producto_valor_total" class="form-control"   >
					</label>
					<div class="help-block with-errors"></div>
				</div>
				<div class="col-12 form-group">
					<label for="pedido_producto_ingredientes"  class="control-label">pedido_producto_ingredientes</label>
					<label class="input-group">
						<div class="input-group-prepend">
							<span class="input-group-text input-icono " ><i class="fas fa-pencil-alt"></i></span>
						</div>
						<input type="text" value="<?= $this->content->pedido_producto_ingredientes; ?>" name="pedido_producto_ingredientes" id="pedido_producto_ingredientes" class="form-control"   >
					</label>
					<div class="help-block with-errors"></div>
				</div>
				<div class="col-12 form-group">
					<label for="pedido_producto_ingredientes_ids"  class="control-label">pedido_producto_ingredientes_ids</label>
					<label class="input-group">
						<div class="input-group-prepend">
							<span class="input-group-text input-icono " ><i class="fas fa-pencil-alt"></i></span>
						</div>
						<input type="text" value="<?= $this->content->pedido_producto_ingredientes_ids; ?>" name="pedido_producto_ingredientes_ids" id="pedido_producto_ingredientes_ids" class="form-control"   >
					</label>
					<div class="help-block with-errors"></div>
				</div>
			</div>
		</div>
		<div class="botones-acciones">
			<button class="btn btn-guardar" type="submit">Guardar</button>
			<a href="<?php echo $this->route; ?>" class="btn btn-cancelar">Cancelar</a>
		</div>
	</form>
</div>