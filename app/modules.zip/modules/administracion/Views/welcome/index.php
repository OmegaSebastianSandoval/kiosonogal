<div class="welcome">
  <img src="/skins/administracion/images/welcome.jpg" alt="">
</div>

<style>
  .welcome {
    display: flex;
    justify-content: center;
    align-items: center;
    height: calc(100vh - 60px);
  }

  .welcome img {
    object-fit: cover;
    width: 100%;
    height: 100%;
  }
</style>