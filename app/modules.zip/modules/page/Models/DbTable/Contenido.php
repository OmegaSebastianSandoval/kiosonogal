<?php 

/**
* 
*/
class Page_Model_DbTable_Contenido extends Db_Table
{
	protected $_name = 'contenido';
	protected $_id = 'contenido_id';
}