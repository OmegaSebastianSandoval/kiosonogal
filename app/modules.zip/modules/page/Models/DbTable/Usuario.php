<?php 

/**
* 
*/
class Page_Model_DbTable_Usuario extends Db_Table
{
	protected $_name = 'user';
	protected $_id = 'user_id';
}